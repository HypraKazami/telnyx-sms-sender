import telnyx
import time
from colorama import Fore, Back, Style

import sys

from colorama import init
init(strip=not sys.stdout.isatty()) # strip colors if stdout is redirected
from termcolor import cprint 
from pyfiglet import figlet_format

cprint(figlet_format('KAZAMI SMS SENDER', font='speed'),
       'green',  attrs=['bold'])

telnyx.api_key = "KEY017C811D9961DCFF869513B02E753660_jgjFMhM0XrmOvOxoEl9Cxv"
phone_numbers = open('numbers.txt', mode='r',
                     encoding='utf-8').read().split('\n')
sms_sender = "+18727660139"
body = 'just a test'

for number in phone_numbers:
        
        if number == "":
            continue
        print(Fore.CYAN+"HYPRA SMS SPAM TO {}".format(number))
        try:
            telnyx.Message.create(
            from_= sms_sender,
            to=number,
            text=body,)
            time.sleep(0.7)
        except Exception as e:
            print("Failed to send sms\n")
            print(str(e))

